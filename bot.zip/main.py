import logging
import aiogram
from aiogram import Bot, Dispatcher, executor, types
import random
from aiogram import executor, types
from PIL import Image, ImageDraw, ImageFont
import resizer
import re
import string
logging.basicConfig(level=logging.INFO)
bot = Bot('5854098012:AAHeI2aaz_acRgUVFC6mxNTtkbltsSsRIW4') 
#bot = Bot('5950549006:AAHvP3KRhE6UiIpS0jlBNymqab4kOQTcvo0')
dp = Dispatcher(bot)
allow = [5720844448,1497284668,5577021336,1040763170]
async def create(id,text,name):
	image = Image.open("image.png")
	draw = ImageDraw.Draw(image)
	font = ImageFont.truetype("font.otf", 28)
	fontn = ImageFont.truetype("font.otf", 32)
	fontv = ImageFont.truetype("font.otf", 32)
	max_width, max_height = 280,50
	name_width, name_height = 140,83#93
	x, y = 430,90
	mess = text
	words = mess.split()
	line = ""
	for word in words:
	   	if word != words[0]:
	   		new_line = line + " " + word
	   		width, height = draw.textsize(new_line, font)
	   		if width > max_width or height > max_height:
	   		   draw.text((x, y), line, fill=(255, 255, 255), font=font)
	   		   line = word
	   		   y += height
	   		else:
	   			line = new_line
	   	if word == words[0]:
	   		new_line = line + word
	   		width, height = draw.textsize(new_line, font)
	   		if width > max_width or height > max_height:
	   		   draw.text((x, y), line, fill=(255, 255, 255), font=font)
	   		   line = word
	   		   y += height
	   		else:
	   			line = new_line
	draw.text((x, y), line, fill=(255, 255, 255), font=font)
	resizer.compress_img()
	re = Image.open("re.png")
	op = "avatar.png"
	photos = await bot.get_user_profile_photos(id)
	if photos.photos:
	       photo = photos.photos[0][-1]
	       file = await bot.get_file(photo.file_id)
	       await bot.download_file(file.file_path, "avatar.png")
	       op = "avatar.png"
	else:
		op = "avatar_def.png"
	ava = Image.open(op)
	#re.resize((1280, 720), Image.ANTIALIAS)
	#re.save("re.png")
	#re.thumbnail((290,290), Image.ANTIALIAS)
	#re.save("re.png")
	image.paste(re, (425,490))
	ava.thumbnail((112,112), Image.ANTIALIAS)
	image.paste(ava, (20,68))
	d = ImageDraw.Draw(image)
	text=name
	offset = 4
	shadowColor = 'black'
	imgWidth,imgHeight = image.size
	x = name_width
	y = name_height
	for off in range(offset):
	   d.text((x-off, y), text, font=fontn, fill=shadowColor)
	   d.text((x+off, y), text, font=fontn, fill=shadowColor)
	   d.text((x, y+off), text, font=fontn, fill=shadowColor)
	   d.text((x, y-off), text, font=fontn, fill=shadowColor)
	   d.text((x-off, y+off), text, font=fontn, fill=shadowColor)
	   d.text((x+off, y+off), text, font=fontn, fill=shadowColor)
	   d.text((x-off, y-off), text, font=fontn, fill=shadowColor)
	   d.text((x+off, y-off), text, font=fontn, fill=shadowColor)
	d.text((x,y), text, font=fontv, fill="#fff")
	image.save("otziv.png")

@dp.message_handler(commands=['icon'], commands_prefix='/')
async def icon(message: types.Message):
	if message.from_user.id in allow:
		id=message['reply_to_message']['photo'][2]['file_id']
		#await message.reply(id)
		file = await bot.get_file(id)
		await bot.download_file(file.file_path, "screen.png")
		await message.reply("Файл скачан!")
	
@dp.message_handler(commands=['info'], commands_prefix='/')
async def t(message: types.Message):
	await message.reply(message)

async def username(mess):
	try:
		name = mess['reply_to_message']["forward_from"]["username"]
		if name == None:
			return False
		else:
			return f"{name}"
	except:
		return False

async def first_name(mess):
	try:
		name = mess['reply_to_message']["forward_from"]["first_name"]
		if name == None:
			return False
		else:
			return f"{name}"
	except:
		return False
		
async def forward_sender_name(mess):
	try:
		name = mess['reply_to_message']["forward_sender_name"]
		if name == None:
			return False
		else:
			return f"{name}"
	except:
		return False
		
async def text_op(mess):
	try:
		text = mess['reply_to_message']['text']
		if text == None:
			return False
		else:
			return text
	except:
		return False
		
async def caption_text(mess):
	try:
		text = mess['reply_to_message']["caption"]
		if text == None:
			return False
		else:
			return text
	except Exception as e:
		print(e)
		return False
	
async def remove_emoji(text):
    emoji_pattern = re.compile("["
                           u"\U0001F600-\U0001F64F"
                           u"\U0001F300-\U0001F5FF"
                           u"\U0001F680-\U0001F6FF"
                           u"\U0001F1E0-\U0001F1FF" 
                           u"\U00002702-\U000027B0"
                           u"\U000024C2-\U0001F251"
                           "]+", flags=re.UNICODE)
    return re.sub(r'[^\w\s]','',emoji_pattern.sub(r'', text))
    
@dp.message_handler(commands=['new'], commands_prefix='/')
async def st(message: types.Message):
		if message.from_user.id in allow:
			id = "no"
			name = "User"
			text = "no"
			oper = [first_name,forward_sender_name,username]
			text_oper = [text_op,caption_text]
			metod = ''
			try:
				id = message['reply_to_message']["forward_from"]["id"]
			except:
				id = 5720844448
				
			for op in oper:
				if await op(message) != False and await op(message) != None and await op(message) != "@None":
					name = await op(message)
					if op == oper[2]:
						metod = "@"
				else:
					pass
					
			for op in text_oper:
				if await op(message) != False and await op(message) != None:
					text = await op(message)
				else:
					pass
					
			new = ''
			if len(name) > 11:
				for n in name:
					if n == name[10]:
						new = f"{new}\n{n}"
					else:
						new = f"{new}{n}"
			else:
				new = name
			new_text = await remove_emoji(text)
			new = await remove_emoji(new)
			new_name = ''
			for lit in new:
				if lit in string.ascii_lowercase or lit in string.digits or lit in string.ascii_uppercase:
					new_name = f"{new_name}{lit}"
				else:
					pass
			if len(new_name) < 5:
				new_name = "Unknown User "
			elif metod == "@":
				new_name = f"@{new_name}"
			print(id," ",bytes(new_text, 'utf-8').decode('utf-8', 'ignore')," ",bytes(new_name, 'utf-8').decode('utf-8', 'ignore'))
			await create(id=id,text=bytes(new_text, 'utf-8').decode('utf-8', 'ignore'),name=bytes(new_name, 'utf-8').decode('utf-8', 'ignore'))
			await message.reply_photo(open('otziv.png','rb'))
@dp.message_handler(commands=["start"], commands_prefix='/.!,:;')
async def start(message: types.Message):
	await message.reply("Создатель: @neol1tic\nИнстуркция:\n1. Сначала на сообщение с покупкой отвечаем /icon\n2. На пересланное сообщение с отзывом пишем /new и ждем!\nОбратите внимание на символы в нике и в тексте если они не стандартные(другой шрифт,неизвестные символы и тд) то бот их прочто проигнорирует! Скажите покупателю чтобы он изменил свои данные!")
#RUN''
if __name__ == '__main__':
    executor.start_polling(dp, skip_updates=True)